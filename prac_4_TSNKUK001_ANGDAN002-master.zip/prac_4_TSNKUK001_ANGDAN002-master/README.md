# prac_4_TSNKUK001_ANGDAN002
This is a git repository for practical 4 embedded systems2
Yes and wil wil be collaborating. 

Lets rock
